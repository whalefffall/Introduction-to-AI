const baseURL = '/api';

const formFetch = (path, args = {}, method = 'POST') => () => {
    const encode = encodeURIComponent;

    return fetch(`${baseURL}${path}`, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        method: method.toUpperCase(),
        credentials: 'include',
        body: Object.keys(args).map(key => `${encode(key)}=${encode(args[key])}`).join('&')
    }).then(response => response.json());
};

export const failURL = `https://cas.sustech.edu.cn/cas/login?service=https://${window.location.hostname}/api/login`;

export default formFetch;