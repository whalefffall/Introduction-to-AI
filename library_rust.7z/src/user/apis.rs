use std::collections::HashMap;
use std::string::String;
use std::sync::Arc;

use rbatis::crud::CRUD;
use rbatis::rbatis::Rbatis;
// use redis::AsyncCommands;
use rocket::{Request, State};
use rocket::form::{Form, Strict};
use rocket::http::{Cookie, CookieJar};
use rocket::response::{content, Redirect, status};
use rocket::response::content::Json;
use serde::de::value::StrDeserializer;

use crate::utils::guards::{IsLogin, RateLimitGuard};

use super::forms;
use super::models::{StaticInfo, User};
use super::responses::StaticResponse;

use deadpool_redis::Pool;
// use  redis::aio::Connection;
use redis::AsyncCommands;
use rocket_governor::RocketGovernor;
use crate::user::forms::{CASResponse, CASResponseForm};
use crate::utils::session::Session;


#[get("/login?<ticket>")]
pub async fn login(ticket: String, _r: RocketGovernor<'_, RateLimitGuard>, rb: &State<Arc<Rbatis>>, cookies: &CookieJar<'_>)
                   -> Redirect {
    // let ticket = ticket.into_inner().ticket.clone();
    let client = reqwest::Client::new();
    let cas_form = [
        ("service", "https://portrait.lib.sustech.edu.cn/api/login"),
        ("format", "JSON"),
        ("ticket", &ticket)
    ];
    let info = client.get("https://cas.sustech.edu.cn/cas/p3/serviceValidate")
        .query(&cas_form)
        // .form(&cas_form)
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap()
    ;
    if let Ok(info) = serde_json::from_str::<CASResponseForm>(&info) {
    
        if let CASResponse::authenticationSuccess(info) = info.serviceResponse {
            let uid = info.attributes.sid[0].clone();
            let result: Option<User> = rb.fetch_by_column("user_id", &uid)
            .await.unwrap();
            if result.is_none() {
                return Redirect::to(uri!("https://portrait.lib.sustech.edu.cn/500"));
            }
            let x = serde_json::to_string(&result.unwrap()).unwrap();
            cookies.add_private(Cookie::new("token", x.clone()));
            return Redirect::to(uri!("https://portrait.lib.sustech.edu.cn"));
        }
    }

    return Redirect::to(uri!("https://portrait.lib.sustech.edu.cn/500"));
}


#[post("/userinfo")]
pub async fn userinfo(userinfo: IsLogin) -> status::Accepted<content::Json<String>> {
    let user = userinfo.0;
    let info = serde_json::to_string(&user).unwrap();
    status::Accepted(Some(content::Json(info)))
}

#[post("/static-info/<type>")]
pub async fn static_info(rb: &State<Arc<Rbatis>>, r#type: String, userinfo: IsLogin) -> status::Accepted<content::Json<String>> {
    let user = userinfo.0;
    let info: Option<StaticInfo> = rb.fetch_by_column("user_id", user.id).await.unwrap();
    let mut ans = StaticResponse { count: 0, length: 0, r#type: 0, percentage: 0.0 };
    if info.is_none() {
        return status::Accepted(Some(Json(serde_json::to_string(&ans).unwrap())));
    }
    let info = info.unwrap();
    match &r#type[..] {
        "book" => {
            ans.count = info.loadbook_count;
            ans.r#type = info.loadbook_type;
            if let Some(p) = info.loadbook_percentage {
                ans.percentage = p;
            }
        }
        "library" => {
            ans.count = info.librarytime_count;
            ans.length = info.librarytime_length;
            if let Some(p) = info.librarytime_percentage {
                ans.percentage = p;
            }
        }
        "discussion-room" => {
            ans.count = info.discussroom_count;
            ans.length = info.discussroom_length;
            if let Some(p) = info.discussroom_percentage {
                ans.percentage = p;
            }
        }
        _ => {}
    };
    return status::Accepted(Some(Json(serde_json::to_string(&ans).unwrap())));
}

#[post("/user-tag")]
pub async fn user_tag(rb: &State<Arc<Rbatis>>, userinfo: IsLogin)
                      -> status::Accepted<content::Json<String>> {
    let user = userinfo.0;
    let info: Option<StaticInfo> = rb.fetch_by_column("user_id", user.id).await.unwrap();
    let mut ans = HashMap::new();
    if info.is_none() {
        ans.insert("tag", "无闻者".to_string());
        ans.insert("title", "花开别处，亦是芬芳".to_string());
        ans.insert("comment", "图书馆等着你的到来！".to_string());
        return status::Accepted(Some(content::Json(serde_json::to_string(&ans).unwrap())));
    }
    let info = info.unwrap();
    if info.librarytime_length == 0 {
        ans.insert("tag", "无闻者".to_string());
        ans.insert("title", "花开别处，亦是芬芳".to_string());
        ans.insert("comment", "图书馆等着你的到来！".to_string());
    } else if info.loadbook_percentage.unwrap() >= 80f32 {
        ans.insert("tag", "博览者".to_string());
        ans.insert("comment", format!("你在图书馆借阅了{}本书籍，超越了{}%的南科人！
", info.loadbook_count, info.loadbook_percentage.unwrap()));
        ans.insert("title", "上知天文，下知地理".to_string());
    } else if info.discussroom_count > 5 {
        ans.insert("tag", "思辩者 ".to_string());
        ans.insert("comment", format!("你一共预约了{}次讨论间，超过了{}%的读者，思想在辩论中捧出火花，祝您遇到的问题都能迎刃而解！",
                                      info.discussroom_count, info.discussroom_percentage.unwrap()));
        ans.insert("title", "集思广益，博采众长".to_string());
    }
    else if info.librarytime_percentage.unwrap() > 60f32 {
        ans.insert("tag", "勤学者".to_string());
        ans.insert("comment", format!("你一共在图书馆学习了{}小时，超越了{}%的南科人！",
                                      info.librarytime_length / 60, info.librarytime_percentage.unwrap()));
        ans.insert("title", "书山有路勤为径".to_string());
    }
    else if info.librarytime_length > 0 && info.loadbook_count == 0 {
        ans.insert("tag", "学习者".to_string());
        ans.insert("comment", " 轻轻的你走了，正如你轻轻的来，不带走一本书".to_string());
        ans.insert("title", "业精于勤，行成于思".to_string());
    } else {
        ans.insert("tag", "思索者".to_string());
        ans.insert("comment", "善于思考，博学多识，您一定是大家的学习榜样！".to_string());
        ans.insert("title", "长路漫漫，上下求索 ".to_string());
    }

    status::Accepted(Some(content::Json(serde_json::to_string(&ans).unwrap())))
}

#[post("/test")]
pub async fn test(_r: RocketGovernor<'_, RateLimitGuard>) -> String {
    "hello".to_string()
}
