use rocket::serde::Serialize;

#[derive(Serialize)]
pub struct LibraryInfo {}