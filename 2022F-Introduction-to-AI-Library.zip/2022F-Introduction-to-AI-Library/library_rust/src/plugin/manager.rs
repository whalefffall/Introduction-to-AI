use dlopen::wrapper::{Container, WrapperApi};
// use serde::Serialize;
use std::collections::HashMap;



// let mut cont: Container<PluginApi> =
//         unsafe { Container::load("/home/satan/Desktop/rustlib/target/debug/librustlib.so") }.expect("Could not open library or load symbols");
//         let config: HashMap<String,String> = HashMap::new();
//         log::info!("{}", unsafe{cont.call(&config, request)});